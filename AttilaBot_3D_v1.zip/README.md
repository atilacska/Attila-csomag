# AttilaBot 3D model - v1

This package contains Cura-compatible STL files for AttilaBot (upright two-wheeled robot). Files are in mm units.

Files:
- wheel_60mm.stl
- base_frame.stl
- motor_mount_left.stl
- motor_mount_right.stl
- esp32_mount.stl
- mpu6050_mount.stl
- dual_18650_holder.stl

Print settings: PLA, 0.2 mm layer, 20% infill.
