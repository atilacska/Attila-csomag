AttilaBot - Kétkerekű Egyensúlyozó Robot (ESP32-WROOM-32)

Tartalom:
- AttilaBot_Foprogram.ino
- ESP32_Installer_Win11.bat
- AttilaBot_Telepitesi_Utmutato.pdf
- Kapcsolasi_Rajz.pdf
- MPU6050_Test/  Motor_Test/
- AttilaBot_Logo.png

Használat (rövid):
1) Töltsd le ezt a ZIP-et.
2) Kövesd a Telepítési útmutatót (Első a kézi telepítés).
3) Ha gond van, futtasd az ESP32_Installer_Win11.bat fájlt rendszergazdaként.
