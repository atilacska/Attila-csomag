#ifndef CONFIG_H
#define CONFIG_H
#define PID_KP 16.5
#define PID_KI 0.8
#define PID_KD 0.9
#define ENABLE_LED_EFFECTS 0
#endif
