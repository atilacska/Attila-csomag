# AttilaBot Modular v2 (230x230 split STL package)

Files in this package:
- base_plate.stl
- motor_mount_left.stl
- motor_mount_right.stl
- wheel_left_60mm.stl
- wheel_right_60mm.stl
- battery_holder_dual_18650.stl
- esp32_cover.stl
- sensor_mount.stl
- spacer_bracket.stl

Print settings: PLA, 0.2 mm layer, 30% infill. Bed 60C, nozzle 200-205C.
